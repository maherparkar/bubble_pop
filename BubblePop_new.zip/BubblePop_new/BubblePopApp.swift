import SwiftUI

@main
struct BubblePopApp: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
}

